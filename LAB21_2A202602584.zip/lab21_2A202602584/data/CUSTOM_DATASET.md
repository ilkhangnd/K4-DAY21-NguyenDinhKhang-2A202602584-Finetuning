# Custom Domain Dataset Specification — Lab 21 (Bonus B2)

## 1. Miền bài toán (Domain) & Mục tiêu

* **Lĩnh vực nghiệp vụ**: Hỗ trợ khách hàng Ngân hàng số & Fintech Việt Nam (Digital Banking & Fintech Customer Support Triage).
* **Bài toán**: Phân loại tự động ticket/khiếu nại đa kênh của người dùng thành cấu trúc JSON 4 trường:
  * `intent`: `khoa_the` | `khieu_nai_giao_dich` | `hoan_phi` | `loi_ung_dung` | `xac_thuc_sinh_trac`
  * `urgency`: `cao` | `trung_binh` | `thap`
  * `product`: `thẻ tín dụng` | `thẻ ghi nợ` | `ứng dụng mobile banking` | `chuyển tiền nhanh 247` | `ví điện tử` | `vay tiêu dùng`
  * `sentiment`: `tieu_cuc` | `trung_tinh` | `tich_cuc`
* **Quy mô tập dữ liệu**: 250 mẫu chuẩn (vượt ngưỡng yêu cầu ≥200 mẫu chất lượng cao).
* **Định dạng lưu trữ**: `data/custom_dataset.jsonl` (mỗi dòng chứa `instruction`, `input`, `output`, `label`, `txn_id`).

---

## 2. Nguồn dữ liệu & Phương pháp thu thập

* **Nguồn dữ liệu (Source)**:
  * Dữ liệu mô phỏng từ các tình huống nghiệp vụ thực tế tại các cổng hỗ trợ khách hàng ngân hàng trực tuyến tại Việt Nam (Vietcombank Digibank, Techcombank Mobile, TPBank, VPBank NEO, MoMo, ZaloPay).
  * Các kịch bản bao gồm các case vận hành nhạy cảm: sự cố quẹt thẻ POS bị trừ tiền kép, nghẽn giao dịch chuyển khoản NAPAS 247, sự cố xác thực sinh trắc học theo Quyết định 2345/QĐ-NHNN (quét NFC căn cước công dân gắn chip), rò rỉ mã OTP / nghi ngờ gian lận tài khoản.
* **Quy trình ẩn danh hóa & bảo vệ PII (Personally Identifiable Information)**:
  * Không sử dụng bất kỳ thông tin thực tế của khách hàng cá nhân.
  * Toàn bộ mã giao dịch được quy chuẩn thành định dạng `TXN########`.
  * Số tài khoản, số thẻ, số CCCD và tên người dùng được thay thế bằng danh xưng ẩn danh (`tôi`, `anh/chị`).

---

## 3. Quy trình khử nhiễm dữ liệu (Decontamination Protocol)

Để đảm bảo tính liêm chính của đánh giá học máy theo Deck §17 & §21, tập dữ liệu tuân thủ quy trình khử nhiễm nghiêm ngặt 3 bước:

1. **Khử trùng lặp chuỗi tuyệt đối (Exact Deduplication)**:
   * Áp dụng SHA-256 băm văn bản đầu vào để loại bỏ 100% các câu trùng khớp verbatim.
2. **Kiểm soát độ tương đồng n-gram (Near-duplicate filtering via 8-gram MinHash / Jaccard)**:
   * Đặt ngưỡng Jaccard similarity trên 8-gram token giữa tập huấn luyện (train) và tập đánh giá (eval) ở mức `< 0.15`.
   * Mọi mẫu có sự trùng lặp mẫu câu hoặc mẫu mã đơn tương tự nhau ở cả hai tập đều bị loại bỏ hoặc viết lại.
3. **Phân chia theo thực thể giao dịch (Entity / Session-level split)**:
   * Mã giao dịch (`txn_id`) và nhóm khách hàng được phân bổ độc lập; không có giao dịch nào xuất hiện đồng thời trong cả tập train và tập eval.
   * Tập eval không bị rò rỉ vào prompt hay fine-tuning corpus dưới bất kỳ hình thức nào.

---

## 4. Phân tích độ mới về phân phối (Distribution Novelty vs Base Model — Deck §3.3)

Theo Deck §3.3, các LLM hiện đại (như Qwen, Llama) đã bão hòa dữ liệu web tiếng Việt phổ thông (báo chí, Wikipedia, mạng xã hội thông thường). Việc fine-tune chỉ đem lại giá trị thực sự nếu phân phối dữ liệu huấn luyện **mới mẻ và mang tính chuyên biệt cao**:

1. **Thuật ngữ Fintech & Quy định pháp lý đặc thù tại Việt Nam**:
   * Các khái niệm mới phát sinh gần đây như *"xác thực sinh trắc học CCCD gắn chip"*, *"quét NFC căn cước"*, *"chuyển khoản hạn mức 10 triệu theo QĐ 2345"*, *"tra soát giao dịch NAPAS"* hoàn toàn không có trong dữ liệu tiền huấn luyện (pre-training) truyền thống của base model.
2. **Đặc thù văn phong hội thoại khách hàng ngành tài chính**:
   * Ngữ cảnh kết hợp giữa sự khẩn cấp cao (ví dụ: *"bị nuốt thẻ ở cây ATM"*, *"nghi ngờ bị hack tài khoản"*) với yêu cầu định dạng đầu ra bắt buộc theo chuẩn SLA nội bộ ngân hàng.
3. **Cấu trúc Ontology nghiêm ngặt**:
   * Base model thông thường có xu hướng trả lời đàm thoại dài dòng hoặc từ chối do nhầm lẫn với tư vấn tài chính. Việc fine-tune trên tập này định hình chính xác khả năng trích xuất trường JSON chuẩn xác 100%, phục vụ việc phân luồng ticket (routing) ngay lập tức tới bộ phận kỹ thuật / trung tâm thẻ.
